#include <stdio.h>
#include <stdlib.h>

struct virus {
    unsigned short SigSize;
    char virusName[16];
    char sig[];
} virus;

void PrintHex(char buffer[], size_t length) {
    int i;
    for(i=0; i<length; i++) {
        fprintf(stdout, "%02hhx ", buffer[i]);
    }
    fprintf(stdout, "\n\n");
}

int main(int argc, char **argv) {
    FILE* viruses = fopen("signatures", "rb");
    if(viruses == NULL)
    {
        fprintf(stderr, "Error opening file. exit program.\n");
        exit(1);
    }
    
    //while(!feof(viruses))
    //{
        int i;
        for(i=0; i<10; i++) 
        {    
            fread(&virus.SigSize, sizeof(unsigned short), 1, viruses);
            struct virus *v = malloc(sizeof(virus) + (virus.SigSize-18));
            if (v == NULL) exit(1);
            
            (*v).SigSize = virus.SigSize-18;
            fread(v->virusName, sizeof(char), 16+(*v).SigSize, viruses);
            fprintf(stdout, "Virus name: %s\nVirus size: %u\nsignature:\n", (*v).virusName, (*v).SigSize);
            PrintHex((*v).sig, (*v).SigSize);
            free(v);
        }
    //}
 
    fclose(viruses);
    return 0;

}