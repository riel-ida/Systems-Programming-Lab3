#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct virus {
    unsigned short SigSize;
    char virusName[16];
    char sig[];
} virus; 

typedef struct link {
    struct link *nextVirus;
    virus *vir;
} link;

link *head = NULL;

struct fun_desc {
  char *name;
  void (*fun)(void);
};

void PrintHex(char buffer[], size_t length) {
    int i;
    for(i=0; i<length; i++) {
        fprintf(stdout, "%02hhx ", buffer[i]);
    }
    fprintf(stdout, "\n\n");
}

void list_print(link *virus_list) {
    while(virus_list != NULL)
    {
        fprintf(stdout, "Virus name: %s\nVirus size: %u\nsignature:\n", (virus_list->vir)->virusName, (virus_list->vir)->SigSize);
        PrintHex((virus_list->vir)->sig, (virus_list->vir)->SigSize);
        virus_list = virus_list->nextVirus;
    }
}
        
 
link* list_append(link* virus_list, virus* data) {
    //allocate memory for the new node 
    link* new_link = (link*)malloc(sizeof(link));     
    //copy contents of given data to the newly allocated memory.  
    new_link->vir = data;
    //append new link at the end of the list
    if(virus_list != NULL)
    {
        //keep pointing at head
        link* tmp = virus_list; 
        
        while(virus_list->nextVirus != NULL)
        {
            printf("in append: %s\n", virus_list->vir->virusName);
            virus_list = virus_list->nextVirus;
        }
        virus_list->nextVirus = new_link;
        virus_list = tmp;
    }
    else
        virus_list = new_link;
    
    return virus_list; 
} 

void load_signatures(void) {
    char sig_Size[2];
    char file_name[11];
    fprintf(stdout, "Please enter a siggnature-file name:\n");
    
    fgets(file_name, 11, stdin);
    if(file_name[strlen(file_name)-1] == '\n')
    {
        file_name[strlen(file_name)-1] = '\0';
    }
    puts(file_name);
    
    FILE* viruses = fopen(file_name, "rb");
    if(viruses == NULL)
    {
        fprintf(stderr, "Error opening file. exit program.\n");
        exit(1);
    }
    
    //while(!feof(viruses))
    for(int i=0; i<10; i++)
    {
        fread(sig_Size, sizeof(char), 2, viruses);
        short size = (short)((sig_Size[1] & 0xff) << 8);
        size += (short)(sig_Size[0] & 0xff)-18;
        printf("Size is: %d\n", size);

        virus *v = malloc(sizeof(virus) + (size));
        if (v == NULL) exit(1);
        (*v).SigSize = size;
        fread(v->virusName, sizeof(char), 16+(*v).SigSize, viruses);
        
        head = list_append(head, v);
        //free(v); TODO
    }
}

void print_signatures(void) {
    if(head != NULL)
    {
        list_print(head);
    }
    exit(0);
}
 
void list_free(link *virus_list) {
   link* tmp;

   while (virus_list != NULL)
   {
       tmp = virus_list;
       virus_list = virus_list->nextVirus;
       free(tmp->vir);
       free(tmp);
   }
}

void quit(void){
    list_free(head);
    exit(0);
}


int main(int argc, char **argv){
    char user_in[2];
    int func_num = 1;
    int i;
    
    struct fun_desc menu[] = { { "Load signatures", &(load_signatures) }, { "Print signatures", &(print_signatures) }, {  "Quit", &(quit) }, { NULL, NULL } };
    
    int bound = (sizeof(menu)/sizeof(struct fun_desc))-1;
    
    while(!(strcmp(menu[func_num-1].name, "Quit")==0))
    {
        fprintf(stdout, "Please choose a function:\n");
        for(i = 0; i < bound; i++) fprintf(stdout, "%d) %s\n", i+1, menu[i].name);
        fprintf(stdout, "Option: ");
        

        fgets(user_in, 2, stdin);
        fgetc(stdin); //taking the "\n" input 
        sscanf(user_in, "%d", &func_num); //convert string datatype to int datatype
        
        if(func_num >= 1 && func_num <= bound)
        {
            fprintf(stdout, "Within bounds\n");
            menu[func_num-1].fun();
            fprintf(stdout, "DONE.\n\n");
        }
        else{
            fprintf(stdout, "Not within bounds\n");
            exit(0);
        }
    }
    
    return 0;
}