#include <stdio.h>
#include <stdlib.h>

void PrintHex(char buffer[], size_t length) {
    int i;
    for(i=0; i<length; i++) {
        fprintf(stdout, "%02hhx ", buffer[i]);
    }
    fprintf(stdout, "\n");
}

int main(int argc, char **argv) {
    char input[128];
    char* name = argv[1];
    FILE* file = fopen(name, "r");
    if(file == NULL)
    {
        fprintf(stderr, "Input file cannot be opened for reading. exit program.\n");
        exit(1);
    }
    size_t length = fread(input, sizeof(char), 128, file);
    PrintHex(input, length);
    
    fclose(file);
    return 0;
}
